export * from '../../../languages/features/typescript/register';
