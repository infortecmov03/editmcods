export * from '../../../languages/features/html/register';
