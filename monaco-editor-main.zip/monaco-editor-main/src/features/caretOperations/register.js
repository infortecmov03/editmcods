import 'monaco-editor-core/esm/vs/editor/contrib/caretOperations/browser/transpose';
