import 'monaco-editor-core/esm/vs/editor/contrib/inlineCompletions/browser/inlineCompletions.contribution';
