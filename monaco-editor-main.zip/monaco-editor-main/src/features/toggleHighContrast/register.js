import 'monaco-editor-core/esm/vs/editor/standalone/browser/toggleHighContrast/toggleHighContrast';
