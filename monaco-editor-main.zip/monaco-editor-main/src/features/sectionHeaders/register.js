import 'monaco-editor-core/esm/vs/editor/contrib/sectionHeaders/browser/sectionHeaders';
