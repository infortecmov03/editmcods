import 'monaco-editor-core/esm/vs/editor/contrib/dropOrPasteInto/browser/dropIntoEditorContribution';
