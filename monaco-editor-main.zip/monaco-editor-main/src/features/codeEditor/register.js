import 'monaco-editor-core/esm/vs/editor/browser/widget/codeEditor/codeEditorWidget';
