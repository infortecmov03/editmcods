import 'monaco-editor-core/esm/vs/editor/contrib/insertFinalNewLine/browser/insertFinalNewLine';
