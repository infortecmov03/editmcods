import 'monaco-editor-core/esm/vs/editor/contrib/parameterHints/browser/parameterHints';
