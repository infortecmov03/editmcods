import 'monaco-editor-core/esm/vs/editor/contrib/suggest/browser/suggestInlineCompletions';
