import 'monaco-editor-core/esm/vs/editor/contrib/anchorSelect/browser/anchorSelect';
