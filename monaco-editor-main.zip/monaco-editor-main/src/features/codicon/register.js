import 'monaco-editor-core/esm/vs/base/browser/ui/codicons/codicon/codicon.css';
