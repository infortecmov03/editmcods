import 'monaco-editor-core/esm/vs/editor/contrib/floatingMenu/browser/floatingMenu.contribution';
