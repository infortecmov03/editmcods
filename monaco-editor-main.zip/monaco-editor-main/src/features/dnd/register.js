import 'monaco-editor-core/esm/vs/editor/contrib/dnd/browser/dnd';
