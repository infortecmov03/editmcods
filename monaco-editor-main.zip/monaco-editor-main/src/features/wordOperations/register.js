import 'monaco-editor-core/esm/vs/editor/contrib/wordOperations/browser/wordOperations';
