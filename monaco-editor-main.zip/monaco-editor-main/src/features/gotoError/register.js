import 'monaco-editor-core/esm/vs/editor/contrib/gotoError/browser/gotoError';
