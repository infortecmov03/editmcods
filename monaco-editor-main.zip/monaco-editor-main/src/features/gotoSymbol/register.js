import 'monaco-editor-core/esm/vs/editor/contrib/gotoSymbol/browser/link/goToDefinitionAtPosition';
