import 'monaco-editor-core/esm/vs/editor/contrib/readOnlyMessage/browser/contribution';
